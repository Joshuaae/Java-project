package com.example.dao;

public class ReturnExample {

	public static void main(String[] args) {
		
	}
	
	static String m1()
	{

		String s ="JBK";

		try
		{
	          

			if(s.length()>2)
				return s;	
		}

	     catch(Exception e)
	     {
		
	     }

		return s;

	}// end of method

}
